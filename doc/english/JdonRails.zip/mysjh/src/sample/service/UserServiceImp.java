/*
 * Copyright 2007 the original author or jdon.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
package sample.service;

import org.apache.log4j.Logger;

import sample.dao.JdbcDao;
import sample.model.User;

import com.jdon.controller.events.EventModel;
import com.jdon.controller.model.PageIterator;

public class UserServiceImp implements UserService {
	private final static Logger logger = Logger.getLogger(UserServiceImp.class);
	
	private JdbcDao jdbcDao;

	public UserServiceImp(JdbcDao jdbcDao) {
		this.jdbcDao = jdbcDao;
	}

	public void create(EventModel em) {
		User user = (User)em.getModel();
		try {
			jdbcDao.insert(user);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}
	public void update(EventModel em){
		User user = (User)em.getModel();
		//确认是否存在这个user;
		try {
			User usero = getUser(user.getId());
			if (usero != null) 
			    jdbcDao.update(user);
		} catch (Exception e) {
			logger.error(e);
		}
	}
	
	/* (non-Javadoc)
	 * @see sample.service.UserService#delete(java.lang.String)
	 */
	public void delete(EventModel em){
		User userp = (User)em.getModel();
		try {
			User user = getUser(userp.getId());
			if (user != null)
				jdbcDao.delete(user);
		} catch (Exception e) {
			logger.error(e);
		}
	}
	
	public  User findUser(Integer id){
		return getUser(id);
	}
	
	/* (non-Javadoc)
	 * @see sample.service.UserService#getUser(java.lang.String)
	 */
	public User getUser(Integer id){
		try {
			return (User)jdbcDao.loadModelById(User.class, id);
		} catch (Exception e) {
			logger.error(e);
			return null;
		}
	}
	
	/* (non-Javadoc)
	 * @see sample.service.UserService#getUsers()
	 */
	public PageIterator getUsers(int start,int count){
		try {
			return jdbcDao.getModels(start, count);
		} catch (Exception e) {
			logger.error(e);
			return new PageIterator();
		}
	}

}
