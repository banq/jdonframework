/*
 * Copyright 2007 the original author or jdon.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
package sample.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import junit.framework.TestCase;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;



import com.jdon.persistence.hibernate.ConfFactory;
import com.jdon.persistence.hibernate.HibernateTemplate;
import com.jdon.persistence.hibernate.SessionProvider;
import com.jdon.persistence.hibernate.util.ThreadLocalSessionProvider;

public class HibernateTemplateTest extends TestCase {
	
	private HibernateTemplate ht;

	protected void setUp() throws Exception {
		super.setUp();
		ConfFactory hibernateConfFactory =  new ConfFactory("/hibernate.cfg.xml");
		SessionFactory sessionFactory = hibernateConfFactory.getSessionFactory();
		SessionProvider sessionProvider = new ThreadLocalSessionProvider(sessionFactory);
		this.ht = new HibernateTemplate(sessionProvider);
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testCreate() {
		
	}
	
	//lazy櫴加载
	public void testGetUser(){
			
	
	}
	
	/**
	 * 设置关系为lazy="false"
	 *
	 */
	public void testGetUserforNoLazy(){
		
	}
	
	
	public void testUpdate(){
		
		
	}
	

}
