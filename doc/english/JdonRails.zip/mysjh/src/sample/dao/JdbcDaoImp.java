/*
 * Copyright 2007 the original author or jdon.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
package sample.dao;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import com.jdon.controller.cache.CacheManager;
import com.jdon.controller.model.PageIterator;
import com.jdon.persistence.DaoCRUD;
import com.jdon.persistence.DaoCRUDTemplate;
import com.jdon.persistence.hibernate.HibernateCRUDTemplate;
import com.jdon.persistence.hibernate.HibernateTemplate;

public class JdbcDaoImp  extends DaoCRUDTemplate implements JdbcDao {
	
	private HibernateTemplate hibernateTemplate;
	
	public JdbcDaoImp(CacheManager cacheManager, DaoCRUD daoCRUD) {
		super(cacheManager, daoCRUD);
		this.hibernateTemplate = ((HibernateCRUDTemplate)daoCRUD).getHibernateTemplate();
		this.hibernateTemplate.setCacheQueries(true);
	}
	
	
	public PageIterator getModels(int start, int count) throws Exception{
		Iterator results = hibernateTemplate.find("select count(user) from User user ")
		                   .iterator();
		Long allcount = new Long(0);
		while ( results.hasNext() ) {
			allcount = (Long) results.next();
		}

		hibernateTemplate.setFirstResult(start);
		hibernateTemplate.setMaxResults(count);
		List pageIds = hibernateTemplate.find("select user.id from User user " + "order by user.id");
		hibernateTemplate.setFirstResult(0);
		hibernateTemplate.setMaxResults(0);
        return new PageIterator(allcount.intValue(), pageIds.toArray());
	}
	
	public Collection getDepts() throws Exception{
		return hibernateTemplate.find(" from Dept ");
	}

}
