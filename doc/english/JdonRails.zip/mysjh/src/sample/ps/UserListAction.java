/*
 * Copyright 2007 the original author or jdon.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
package sample.ps;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import sample.service.UserService;

import com.jdon.controller.WebAppUtil;
import com.jdon.controller.model.Model;
import com.jdon.controller.model.PageIterator;
import com.jdon.strutsutil.ModelListAction;

public class UserListAction extends ModelListAction{
	private final static Logger logger = Logger.getLogger(UserListAction.class);

    /**
     *
     * @param request HttpServletRequest
     * @param key Object
     * @return Model
     * @todo Implement this
     *   com.jdon.strutsutil.ModelListAction method
     */
    public Model findModelByKey(HttpServletRequest request, Object key) {
      Model model = null;
      try {
          logger.debug("get the model for primary key=" + key + " type:"+ key.getClass().getName());
          UserService userService = (UserService) WebAppUtil.getService("userService", request);
          Integer keyI = (Integer)key;
          model = userService.getUser(keyI.intValue());
      } catch (Exception ex) {
          logger.debug("get the model for primary key=" + key + " type:"+ key.getClass().getName());
          logger.error(" error: " + ex);
      }
      return model;

    }

    /**
     *
     * @param request HttpServletRequest
     * @param start int
     * @param count int
     * @return PageIterator
     * @todo Implement this
     *   com.jdon.strutsutil.ModelListAction method
     */
    public PageIterator getPageIterator(HttpServletRequest request, int start,
                                        int count) {
      PageIterator pageIterator = null;
      try {
    	  UserService userService = (UserService) WebAppUtil.getService("userService", request);
        pageIterator = userService.getUsers(start, count);
      } catch (Exception ex) {
          logger.error(ex);
      }
      return pageIterator;
    }
}
